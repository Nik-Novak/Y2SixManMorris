
public enum State {//state enum for enumerating different states
SETTING, PLACING, MOVING, FLYING
}
