import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AI {
	private String colour;
	Board board;
	
	class Move implements Comparable<Move>{
		int positionIndex;
		int score;
		Move(int posIndex, int score){ positionIndex=posIndex; this.score=score;}
		@Override
		public int compareTo(Move o) {
			return o.score-score;
		}
	}
	
	public AI(String colour, Board board){
		this.colour=colour;
		this.board = board;
	}
	
	public String getColour(){ return colour; }
	
	public boolean place(Chip c, int pos){
		board.setSelected(c);
		board.setClicked(c);
		boolean success = c.snapTo(board.getPos()[pos].getLoc());
		if(success)
			board.turnCheck();
		board.setSelected(null);
		board.setClicked(null);
		return success;
	}

	public void move(Data data) {
		if(board.getPlayerTurn().split(" ")[0].equals("Remove")){
			System.out.println("AI REMOVE");
			return;
		}
		State state = data.state();
		if(state==State.PLACING){
			List<Move> s = computeBestPlace(data);
			s.sort(null);
			for(Move i : s){
				if(place(board.getFirstUnplaced(colour), i.positionIndex))
					break;
			}
		}
		else if(state == State.MOVING || state == State.FLYING)
			return;
	}
	

	private List<Move> computeBestPlace(Data data) {
		Data copy = data.deepCopy();
		List<Move> s = new ArrayList<Move>();
		for(int i=0; i!=copy.getPos().length; i++){
			if(copy.getPos()[i].getChip()!=null)
				continue;
			copy.getPos()[i].setChip(new Chip(colour, copy.getPos()[i], null));
			int score = score(copy);
			s.add(new Move(i,score));
			copy.getPos()[i].setChip(null);
		}
		return s;
	}

	private int computeBestMove(Data data) {
		return -1;
	}

	private int score(Data copy) {
		int score = 0;
		
		//Horizontal
		score+=score(0,1,2, copy);
		score+=score(3,4,5, copy);
		score+=score(10,11,12, copy);
		score+=score(13,14,15, copy);
		
		//Vertical
		score+=score(0, 6, 13, copy);
		score+=score(3,7,10, copy);
		score+=score(5,8,12, copy);
		score+=score(2,9,15, copy);
				
		return score;
	}
	
	private int score(int n1, int n2, int n3, Data copy){
		int numAlly =0, numEnem=0;
		int score = 0;
		Position p1 = copy.getPos()[n1];
		Position p2 = copy.getPos()[n2];
		Position p3 = copy.getPos()[n3];
		
		if(p1.getChip()!=null){
			if(p1.getChip().getType().equals(colour))
				numAlly++;
			else
				numEnem++;
		}
		//same as above
		if(p2.getChip()!=null){if(p2.getChip().getType().equals(colour))numAlly++;else numEnem++;}
		//same as p1
		if(p3.getChip()!=null){if(p3.getChip().getType().equals(colour))numAlly++;else numEnem++;}
		score+=Math.pow(numAlly, 2);
		score-=Math.pow(numEnem, 2);
		
		if(numEnem==2 && numAlly == 1)
			score = 8;
		
		if((numEnem + numAlly) == 3)
			if(numEnem>0 && numAlly > 0)
				score = 0;
		
		return score;
	}
}
